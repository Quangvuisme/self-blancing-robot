#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QtSerialPort>
#include<QPixmap>
#include <QRandomGenerator>
#include <QDateTime>
#include <QVector>
QSerialPort* serialPort;

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
    , dataTimer(new QTimer(this))
    , currentTime(0.0)
    , latestAngle(0.0)
{
    ui->setupUi(this);
    serialPort = new QSerialPort(this);
    QPixmap pix("C:/atailieuhoc/ktlt/qt/qt_pic/logogust");
    ui->label_pic->setPixmap(pix.scaled(150, 150, Qt::KeepAspectRatio));

    // Cấu hình cổng com
    serialPort->setPortName("com7");
    serialPort->setBaudRate(QSerialPort::Baud9600);
    serialPort->setDataBits(QSerialPort::Data8);
    serialPort->setParity(QSerialPort::NoParity);
    serialPort->setStopBits(QSerialPort::OneStop);
    serialPort->open(QIODevice::ReadWrite);

    connect(ui->right, SIGNAL(pressed()), this, SLOT(on_right_pressed()));
    connect(ui->left, SIGNAL(pressed()), this, SLOT(on_left_pressed()));
    connect(ui->up, SIGNAL(pressed()), this, SLOT(on_up_pressed()));
    connect(ui->down, SIGNAL(pressed()), this, SLOT(on_down_pressed()));
    connect(ui->up, SIGNAL(released()), this, SLOT(on_up_released()));
    connect(ui->down, SIGNAL(released()), this, SLOT(on_down_released()));
    connect(ui->left, SIGNAL(released()), this, SLOT(on_left_released()));
    connect(ui->right, SIGNAL(released()), this, SLOT(on_right_released()));
    connect(ui->Start, SIGNAL(clicked()), this, SLOT(on_Start_clicked()));
    connect(ui->Cancel, SIGNAL(clicked()), this, SLOT(on_Cancel_clicked()));
    connect(ui->pushButton_5, SIGNAL(clicked()), this, SLOT(on_pushButton_5_clicked()));
    connect(ui->pushButton_6, SIGNAL(clicked()), this, SLOT(on_pushButton_6_clicked()));
    connect(serialPort, SIGNAL(readyRead()), this, SLOT(serialport_read()));

    this->setWindowTitle("Bài Tập Nhóm");

    // Vẽ biểu đồ

    setupPlot();

    // Cập nhật thời gian và khai báo
    //connect(dataTimer, &QTimer::timeout, this, &MainWindow::updatePlot);
   // dataTimer->start(100); // Cập nhật thời gian 100ms

    // Khai báo timeData và angleData
   // timeData.reserve(100);
   // angleData.reserve(100);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_right_pressed()
{
    serialPort->write("\nR");
}

void MainWindow::on_up_pressed()
{
    serialPort->write("\nF");
}

void MainWindow::on_left_pressed()
{
    serialPort->write("\nL");
}

void MainWindow::on_down_pressed()
{
    serialPort->write("\nB");
}

void MainWindow::on_pushButton_3_clicked()
{
    serialPort->write("\nKP");
    serialPort->write(ui->lineEdit->text().toStdString().data());
}

void MainWindow::on_pushButton_clicked()
{
    serialPort->write("\nKD");
    serialPort->write(ui->lineEdit_2->text().toStdString().data());
}

void MainWindow::on_pushButton_2_clicked()
{
    serialPort->write("\nKI");
    serialPort->write(ui->lineEdit_3->text().toStdString().data());
}

void MainWindow::on_pushButton_4_clicked()
{
    serialPort->write("\nKS");
    serialPort->write(ui->lineEdit_4->text().toStdString().data());
}

void MainWindow::serialport_read()
{
    static QByteArray buffer;
    buffer.append(serialPort->readAll());

    // Tìm kiếm ký tự kết thúc (ví dụ: newline)
    int endIndex;
    while ((endIndex = buffer.indexOf('\n')) != -1) {
        // Tách chuỗi đến ký tự kết thúc
        QByteArray data = buffer.left(endIndex);
        buffer.remove(0, endIndex + 1);

        // Chuyển đổi dữ liệu từ QByteArray sang double
        QString dataString = QString::fromUtf8(data).trimmed();
        bool ok;
        double angle = dataString.toDouble(&ok);
        if (ok) {
            // Lưu giá trị angle để sử dụng trong updatePlot()
            latestAngle = angle;
        }

        // Hiển thị dữ liệu đọc được lên plainTextEdit
        ui->plainTextEdit->moveCursor(QTextCursor::End);
        ui->plainTextEdit->insertPlainText(dataString + "\n");
    }
}

void MainWindow::on_up_released()
{
    serialPort->write("\nS");
}

void MainWindow::on_left_released()
{
    serialPort->write("\nS");
}

void MainWindow::on_right_released()
{
    serialPort->write("\nS");
}

void MainWindow::on_down_released()
{
    serialPort->write("\nS");
}

void MainWindow::setupPlot()
{
    // Thiết lập biểu đồ
    ui->customPlot->addGraph();
    ui->customPlot->graph(0)->setScatterStyle(QCPScatterStyle::ssCircle);
    ui->customPlot->graph(0)->setLineStyle(QCPGraph::lsLine);
    ui->customPlot->xAxis->setLabel("Time");
    ui->customPlot->yAxis->setLabel("Angle");
    ui->customPlot->xAxis->setRange(0, 2);
    ui->customPlot->yAxis->setRange(-3, 3);
    ui->customPlot->setInteractions(QCP::iRangeDrag | QCP::iRangeZoom | QCP::iSelectPlottables);
}

void MainWindow::updatePlot()
{
    // Tăng thời gian hiện tại
    currentTime += 0.2; // 0.2s

    // Thêm dữ liệu vào vector
    timeData.append(currentTime);
    angleData.append(latestAngle);

    if (timeData.size() > 100) {
        timeData.removeFirst();
        angleData.removeFirst();
    }

    // Cập nhật và vẽ biểu đồ
    plotData();
}

void MainWindow::plotData()
{
    ui->customPlot->graph(0)->setData(timeData, angleData);

    ui->customPlot->xAxis->setRange(timeData.first(), timeData.last());
    ui->customPlot->yAxis->setRange(*std::min_element(angleData.begin(), angleData.end()),
                                    *std::max_element(angleData.begin(), angleData.end()));

    ui->customPlot->replot();
}

void MainWindow::on_Start_clicked()
{
    connect(dataTimer, &QTimer::timeout, this, &MainWindow::updatePlot);
    dataTimer->start(100); // Cập nhật thời gian 100ms

    timeData.clear(); // Xóa dữ liệu cũ
    angleData.clear(); // Xóa dữ liệu cũ
    // Khai báo timeData và angleData
    timeData.reserve(100);
    angleData.reserve(100);
}


void MainWindow::on_Cancel_clicked()
{
    disconnect(dataTimer, &QTimer::timeout, this, &MainWindow::updatePlot);
}


void MainWindow::on_pushButton_5_clicked()
{
    serialPort->write("\nVR");
    serialPort->write(ui->lineEdit_5->text().toStdString().data());
}


void MainWindow::on_pushButton_6_clicked()
{
    serialPort->write("\nVL");
    serialPort->write(ui->lineEdit_6->text().toStdString().data());
}

